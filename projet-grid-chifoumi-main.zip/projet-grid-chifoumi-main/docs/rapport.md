# Rapport de projet

## Groupe
* XXX
* YYY

## Description des choix importants d'implémentation

Blablabla

## Description des stratégies proposées

Blablabla

## Description des résultats
Comparaison entre les stratégies. Bien indiquer les cartes utilisées.

Blablabla
